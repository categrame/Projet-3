#This file contain constantes of McGyver Labyrinth Game


#Window parameters
NUMBER_OF_SPRITE = 15
SPRITE_SIZE = 40
WINDOW_SPRITE = NUMBER_OF_SPRITE * SPRITE_SIZE

WINDOW_TITLE = "McGyver Labyrinth"